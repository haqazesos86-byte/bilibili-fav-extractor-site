/**
 * popup.js — 精简可靠版
 * 连接: mainWorldFetch (executeScript world:MAIN)
 * 提取: executeScript 注入一次，主世界循环抓取 → postMessage → content.js 收 → storage
 */
(function () {
  'use strict';

  var EL = {};
  function q(id) { return document.getElementById(id); }
  function cache() {
    EL.statusText = q('status-text');
    EL.connectionStatus = q('connection-status');
    EL.cookieInput = q('cookie-input');
    EL.cookieStatus = q('cookie-status');
    EL.limitInput = q('limit-input');
    EL.btnConnect = q('btn-connect');
    EL.btnClearCookie = q('btn-clear-cookie');
    EL.warning = q('not-bilibili-warning');
    EL.folderSection = q('folder-section');
    EL.folderSelect = q('folder-select');
    EL.userInfo = q('user-info');
    EL.btnStart = q('btn-start');
    EL.btnCancel = q('btn-cancel');
    EL.progressFill = q('progress-fill');
    EL.progressPage = q('progress-page');
    EL.progressCount = q('progress-count');
    EL.progressStatus = q('progress-status');
    EL.errorMessage = q('error-message');
    EL.statAI = q('stat-ai');
    EL.statTool = q('stat-tool');
    EL.statBiz = q('stat-biz');
    EL.statTotal = q('stat-total');
    EL.diag = q('diagnostic-text');
    EL.idle = q('state-idle');
    EL.extracting = q('state-extracting');
    EL.done = q('state-done');
    EL.error = q('state-error');
  }

  var state = { tabId: null, tabUrl: '', folders: [], lastResult: null, winId: null };

  var diagLines = [];
  function diag(m) { diagLines.push('[' + new Date().toLocaleTimeString() + '] ' + m); if (EL.diag) { EL.diag.textContent = diagLines.join('\n'); EL.diag.scrollTop = EL.diag.scrollHeight; } }

  var BILI_KEYS = ['SESSDATA', 'bili_jct', 'DedeUserID'];

  function smartParse(text) {
    var r = {};
    if (!text) return r;
    text = text.replace(/^﻿/, '').trim();
    try { var j = JSON.parse(text);
      if (Array.isArray(j)) j.forEach(function (i) { if (i.name) r[i.name] = String(i.value); });
      else BILI_KEYS.forEach(function (k) { if (j[k]) r[k] = String(j[k]); });
      if (r.SESSDATA) return r;
    } catch (e) {}
    var p = [{ k: 'SESSDATA', re: /SESSDATA\s*[=:]\s*"?([a-zA-Z0-9_%-]+)"?/ }, { k: 'bili_jct', re: /bili_jct\s*[=:]\s*"?([a-zA-Z0-9_%-]+)"?/ }, { k: 'DedeUserID', re: /DedeUserID\s*[=:]\s*"?(\d+)"?/ }];
    p.forEach(function (x) { var m = text.match(x.re); if (m) r[x.k] = m[1]; });
    if (r.SESSDATA) return r;
    text.split(/[;\n]/).forEach(function (s) { var i = s.indexOf('='); if (i > 0) { var k = s.slice(0, i).trim(); var v = s.slice(i + 1).trim().replace(/^["']|["']$/g, ''); if (BILI_KEYS.indexOf(k) >= 0) r[k] = v; } });
    return r;
  }

  async function setCookies(map) {
    var n = 0;
    for (var k in map) {
      try {
        await chrome.cookies.set({ url: 'https://api.bilibili.com', name: k, value: map[k], domain: '.bilibili.com', path: '/', secure: true, sameSite: 'no_restriction', httpOnly: k === 'SESSDATA' });
        n++;
      } catch (e) {}
    }
    return n;
  }

  async function dnRule(cookies) {
    if (!cookies) return;
    var parts = [];
    for (var k in cookies) parts.push(k + '=' + cookies[k]);
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1001],
      addRules: [{ id: 1001, priority: 1, action: { type: 'modifyHeaders', requestHeaders: [{ header: 'Cookie', operation: 'set', value: parts.join('; ') }] }, condition: { urlFilter: '||api.bilibili.com/', resourceTypes: ['xmlhttprequest', 'other'] } }],
    });
  }

  // ============================================================
  // mainWorldFetch
  // ============================================================
  function mwFetch(url) {
    return new Promise(function (resolve, reject) {
      var done = false;
      setTimeout(function () { if (!done) { done = true; reject(new Error('timeout')); } }, 10000);
      chrome.scripting.executeScript({
        target: { tabId: state.tabId }, world: 'MAIN',
        func: async function (u) { try { var r = await fetch(u, { credentials: 'include' }); return JSON.parse(await r.text()); } catch (e) { return null; } },
        args: [url],
      }).then(function (a) { if (done) return; done = true; var v = a && a[0] && a[0].result; if (v && v.code !== undefined) resolve(v); else reject(new Error('fetch failed')); })
        .catch(function (e) { if (!done) { done = true; reject(e); } });
    });
  }

  // ============================================================
  // 连接
  // ============================================================
  async function getFolders() {
    var d = await mwFetch('https://api.bilibili.com/x/web-interface/nav');
    if (!d || d.code !== 0) throw new Error('nav: code=' + (d ? d.code : 'null'));
    if (!d.data || !d.data.mid) throw new Error('not login');
    var mid = d.data.mid;

    var d1 = await mwFetch('https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=' + mid);
    function ex(d) { var r = []; if (!d) return r; var list = Array.isArray(d) ? d : (d.list || []); list.forEach(function (f) { var id = f.id || f.media_id; var nm = f.title || f.name; if (id && nm) r.push({ media_id: id, name: nm, count: f.media_count || f.cnt || 0 }); }); return r; }
    var folders = ex(d1 && d1.code === 0 ? d1.data : null);
    try { var d2 = await mwFetch('https://api.bilibili.com/x/v3/fav/folder/collected/list?up_mid=' + mid); if (d2 && d2.code === 0) folders = folders.concat(ex(d2.data)); } catch (e) {}
    return { uname: d.data.uname, folders: folders };
  }

  async function connect() {
    EL.cookieStatus.textContent = '';
    setStatus('连接中...', 'loading');
    diagLines = []; diag('=== connect ===');
    try {
      var text = EL.cookieInput.value.trim();
      if (text) {
        var p = smartParse(text);
        if (!p.SESSDATA) throw new Error('no SESSDATA');
        var n = await setCookies(p);
        await chrome.storage.local.set({ biliCookies: p });
        await dnRule(p);
        diag('cookies ' + n + '/' + Object.keys(p).length);
      } else { diag('no paste, use login'); }
      var info = await getFolders();
      state.folders = info.folders;
      if (!info.folders.length) throw new Error('empty folders');
      EL.userInfo.textContent = '👤 ' + info.uname; EL.userInfo.style.display = 'block';
      EL.folderSelect.innerHTML = '';
      info.folders.forEach(function (f, i) { var o = document.createElement('option'); o.value = i; o.textContent = f.name + ' (' + (f.count || '?') + ')'; EL.folderSelect.appendChild(o); });
      EL.folderSection.style.display = 'block'; EL.btnStart.disabled = false;
      setStatus('✅ ' + info.uname, 'ok'); EL.cookieStatus.textContent = '✅ ' + info.folders.length + ' 个收藏夹';
      diag('ok: ' + info.folders.length + ' folders');
    } catch (e) {
      setStatus('❌ 连接失败', 'error'); EL.cookieStatus.textContent = e.message; diag('err: ' + e.message);
    }
  }

  function setStatus(t, c) { var mk = { loading: 'status-loading', ok: 'status-ok', error: 'status-error' }; EL.connectionStatus.className = 'connection-status ' + (mk[c] || 'status-pending'); EL.statusText.textContent = t; }
  function showState(s) { [EL.idle, EL.extracting, EL.done, EL.error].forEach(function (e) { if (e) e.style.display = 'none'; }); if (s === 'extracting' && EL.extracting) EL.extracting.style.display = 'block'; else if (s === 'done' && EL.done) EL.done.style.display = 'block'; else if (s === 'error' && EL.error) EL.error.style.display = 'block'; else if (EL.idle) EL.idle.style.display = 'block'; }
  function formatNum(n) { return Number(n).toLocaleString(); }

  // ============================================================
  // 提取 — executeScript 一次注入，主世界全量抓取
  // ============================================================
  async function startExtraction() {
    var idx = parseInt(EL.folderSelect.value);
    var f = state.folders[idx];
    if (!f) return;
    var limit = parseInt(EL.limitInput.value) || 0;
    diag('extract: media_id=' + f.media_id + ' limit=' + (limit || 'all'));

    showState('extracting');
    EL.progressFill.style.width = '0%'; EL.progressPage.textContent = '请稍候...'; EL.progressCount.textContent = '正在抓取';
    EL.progressStatus.textContent = '提取中，请等待';
    chrome.storage.local.remove('lastExtraction');

    // 打开独立进度窗口
    chrome.windows.create({ url: 'progress.html', type: 'popup', width: 420, height: 320, focused: true }).then(function (w) {
      state.winId = w.id;
    }).catch(function () {});

    // executeScript 注入完整提取脚本
    diag('注入提取脚本...');
    try {
      var results = await chrome.scripting.executeScript({
        target: { tabId: state.tabId },
        world: 'MAIN',
        func: async function (mediaId, limit) {
          var all = [];
          var tpl = 'https://api.bilibili.com/x/v3/fav/resource/list?media_id=' + mediaId;
          window.__biliCancel = false;
          var conErr = 0;
          for (var pn = 1; pn <= 700; pn++) {
            if (window.__biliCancel) break;
            try {
              var ctrl = new AbortController();
              var to = setTimeout(function () { ctrl.abort(); }, 10000);
              var r, d;
              try {
                r = await fetch(tpl + '&pn=' + pn + '&ps=40&order=mtime&type=0&platform=web&web_location=333.1387', { signal: ctrl.signal, credentials: 'include' });
                clearTimeout(to);
                d = JSON.parse(await r.text());
              } catch (fetchErr) {
                clearTimeout(to);
                if (window.__biliCancel) break;
                conErr++;
                if (conErr >= 5) break;
                if (fetchErr.name === 'AbortError') { await new Promise(function (q) { setTimeout(q, 3000); }); pn--; continue; }
                await new Promise(function (q) { setTimeout(q, 3000); });
                pn--;
                continue;
              }
              conErr = 0;
              if (d.code === -412) { await new Promise(function (q) { setTimeout(q, 300000); }); continue; }
              if (d.code !== 0) { conErr++; continue; }
              if (!d.data) { conErr++; continue; }
              var list = (d.data && d.data.medias) || [];
              if (!list.length) { conErr++; continue; }
              for (var i = 0; i < list.length; i++) {
                if (limit > 0 && all.length >= limit) { window.__biliCancel = true; break; }
                var m = list[i]; all.push({ t: (m.title || '').replace(/<[^>]+>/g, ''), a: (m.author && m.author.name) || '', b: m.bvid || '', id: m.id || 0, fav_time: m.fav_at || m.ctime || 0 });
              }
              window.postMessage({ __bili: 'p', page: pn, total: all.length, pagesTotal: Math.ceil((d.data && d.data.page && d.data.page.count) / 40) || pn }, '*');
              if (window.__biliCancel) break;
              if (!d.data || d.data.has_more === false || d.data.has_more === 0 || !list.length) break;
              await new Promise(function (q) { setTimeout(q, 500); });
            } catch (e) { break; }
          }
          window.postMessage({ __bili: 'result', videos: all, cancelled: window.__biliCancel }, '*');
          return all;
        },
        args: [String(f.media_id), limit],
      });

      var videos = (results && results[0] && results[0].result) || [];
      diag('抓取完成: ' + videos.length + ' 条');

      if (videos.length === 0) { EL.progressStatus.textContent = '未获取到视频'; return; }

      // 加载自定义主题
      var customCats = [];
      try { var td = await chrome.storage.local.get('customThemes'); if (td.customThemes) customCats = td.customThemes; } catch (e) {}

      var result = window.BiliFav.classifyAll(videos, customCats);
      chrome.storage.local.set({ lastExtraction: { mediaId: f.media_id, videos: videos, result: result, timestamp: Date.now() } });
      state.lastResult = result;
      // 保存到历史记录
      saveHistory({ id: Date.now(), folderName: f.name, total: result.stats.total, timestamp: Date.now(), result: result });
      showDone(result.stats);
      EL.progressStatus.textContent = '✅ 完成! ' + result.stats.total + ' 条';
    } catch (err) {
      diag('extract err: ' + err.message);
      EL.progressStatus.textContent = '错误: ' + err.message;
    }
  }

  function showDone(st) { showState('done');
    var hasCustom = st.custom && Object.keys(st.custom).length > 0;
    EL.statTotal.textContent = formatNum(st.total);

    // 内置分类（有自定义时隐藏）
    var aiEl = EL.statAI ? EL.statAI.parentElement : null;
    var toolEl = EL.statTool ? EL.statTool.parentElement : null;
    var bizEl = EL.statBiz ? EL.statBiz.parentElement : null;
    if (aiEl) aiEl.style.display = hasCustom ? 'none' : '';
    if (toolEl) toolEl.style.display = hasCustom ? 'none' : '';
    if (bizEl) bizEl.style.display = hasCustom ? 'none' : '';
    if (!hasCustom) {
      EL.statAI.textContent = formatNum(st.ai);
      EL.statTool.textContent = formatNum(st.tool);
      EL.statBiz.textContent = formatNum(st.biz);
    }

    // 自定义分类
    var customStats = document.getElementById('custom-stats');
    if (customStats) {
      customStats.innerHTML = '';
      if (hasCustom) {
        for (var name in st.custom) {
          var div = document.createElement('div');
          div.className = 'stat-item';
          div.style.cssText = 'grid-column:1/-1';
          div.innerHTML = '<span class="stat-num" style="color:#7b1fa2">' + formatNum(st.custom[name]) + '</span><span class="stat-label">' + name + '</span>';
          customStats.appendChild(div);
        }
      }
    }
  }
  function showError(m) { EL.errorMessage.textContent = m; showState('error'); }
  function downloadHTML() { var r = state.lastResult; if (r) dl(window.BiliFav.genHTML(r), 'bilibili笔记.html', 'text/html;charset=utf-8'); }
  function downloadMarkdown() { var r = state.lastResult; if (r) dl(window.BiliFav.genMarkdown(r), 'bilibili笔记.md', 'text/markdown;charset=utf-8'); }
  function dl(c, n, m) { var b = new Blob([c], { type: m }); var u = URL.createObjectURL(b); var a = document.createElement('a'); a.href = u; a.download = n; a.click(); URL.revokeObjectURL(u); }

  // 接收 content.js 转发的进度消息（postMessage → content.js → chrome.runtime.sendMessage）
  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg.action === 'extractProgress') {
      var pct = msg.pagesTotal > 0 ? Math.round(msg.page / msg.pagesTotal * 100) : 0;
      if (EL.progressFill) EL.progressFill.style.width = pct + '%';
      if (EL.progressPage) EL.progressPage.textContent = '第 ' + msg.page + ' 页';
      if (EL.progressCount) EL.progressCount.textContent = '已获取 ' + (msg.total || 0) + ' 条';
    }
  });

  // ============================================================
  // 初始化
  // ============================================================
  async function init() {
    cache(); showState('idle');
    var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs.length) { setStatus('no tab', 'error'); return; }
    state.tabId = tabs[0].id; state.tabUrl = tabs[0].url || '';
    if (!/bilibili\.com/i.test(state.tabUrl)) { EL.warning.style.display = 'block'; setStatus('❌ 不在 bilibili.com', 'error'); return; }
    setStatus('就绪', 'idle');
    try { var d = await chrome.storage.local.get('biliCookies'); if (d.biliCookies && d.biliCookies.SESSDATA) { var s = ''; for (var k in d.biliCookies) s += k + '=' + d.biliCookies[k] + ';\n'; EL.cookieInput.value = s; } } catch (e) {}
    try { var ld = await chrome.storage.local.get('lastExtraction'); if (ld.lastExtraction && ld.lastExtraction.result) { state.lastResult = ld.lastExtraction.result; document.getElementById('previous-results').style.display = 'block'; } } catch (e) {}
    // 加载自定义主题
    renderThemes();
    // 加载历史记录
    renderHistory();
  }

  // ============================================================
  // 自定义主题管理
  // ============================================================
  async function getThemes() {
    try { var d = await chrome.storage.local.get('customThemes'); return d.customThemes || []; } catch (e) { return []; }
  }
  async function saveThemes(arr) {
    await chrome.storage.local.set({ customThemes: arr });
    renderThemes();
  }
  async function renderThemes() {
    var el = document.getElementById('theme-list');
    if (!el) return;
    var arr = await getThemes();
    if (!arr.length) { el.innerHTML = '<span style="font-size:12px;color:#555">暂无自定义主题</span>'; return; }
    el.innerHTML = arr.map(function (t, i) {
      return '<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 6px;margin:2px 0;background:#0d1b2a;border-radius:4px;font-size:12px">' +
        '<span><b>' + escHtml(t.name) + '</b> <span style="color:#666">(' + (t.keys || []).length + ' 关键词)</span></span>' +
        '<button class="del-theme" data-i="' + i + '" style="background:0;border:0;color:#f44336;cursor:pointer;font-size:14px">✕</button></div>';
    }).join('');
    el.querySelectorAll('.del-theme').forEach(function (btn) {
      btn.addEventListener('click', async function () {
        var arr2 = await getThemes();
        var idx = parseInt(this.getAttribute('data-i'));
        arr2.splice(idx, 1);
        await saveThemes(arr2);
      });
    });
  }
  function escHtml(s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  // ============================================================
  // 提取历史记录
  // ============================================================
  async function saveHistory(entry) {
    try {
      var d = await chrome.storage.local.get('extractionHistory');
      var history = d.extractionHistory || [];
      history.unshift(entry);
      // 最多保留 10 条
      if (history.length > 10) history = history.slice(0, 10);
      await chrome.storage.local.set({ extractionHistory: history });
      renderHistory();
    } catch (e) {}
  }

  async function renderHistory() {
    var el = document.getElementById('history-list');
    if (!el) return;
    try {
      var d = await chrome.storage.local.get('extractionHistory');
      var history = d.extractionHistory || [];
      if (!history.length) { el.innerHTML = '<span style="font-size:12px;color:#555">暂无历史记录</span>'; return; }
      el.innerHTML = history.map(function (h, i) {
        var date = new Date(h.timestamp).toLocaleString('zh-CN');
        return '<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 8px;margin:3px 0;background:#0d1b2a;border-radius:4px;font-size:12px">' +
          '<span style="flex:1"><b>' + escHtml(h.folderName) + '</b> <span style="color:#888">' + h.total + '条</span><br><span style="color:#555;font-size:10px">' + date + '</span></span>' +
          '<span><button class="hist-view" data-i="' + i + '" style="background:#1a73e8;border:0;color:#fff;border-radius:3px;cursor:pointer;padding:3px 8px;font-size:11px">查看</button> ' +
          '<button class="hist-del" data-i="' + i + '" style="background:0;border:0;color:#f44336;cursor:pointer;font-size:14px;padding:2px 4px">✕</button></span></div>';
      }).join('');
      el.querySelectorAll('.hist-view').forEach(function (btn) {
        btn.addEventListener('click', async function () {
          try {
            var idx = parseInt(this.getAttribute('data-i'));
            var d2 = await chrome.storage.local.get('extractionHistory');
            var hist = d2.extractionHistory || [];
            if (hist[idx]) { state.lastResult = hist[idx].result; showDone(hist[idx].result.stats); }
          } catch (e) {}
        });
      });
      el.querySelectorAll('.hist-del').forEach(function (btn) {
        btn.addEventListener('click', async function () {
          try {
            var idx = parseInt(this.getAttribute('data-i'));
            var d2 = await chrome.storage.local.get('extractionHistory');
            var hist = d2.extractionHistory || [];
            hist.splice(idx, 1);
            await chrome.storage.local.set({ extractionHistory: hist });
            renderHistory();
          } catch (e) {}
        });
      });
    } catch (e) {}
  }

  document.addEventListener('DOMContentLoaded', function () {
    cache();
    // 不管 init 完成与否，先把事件绑上
    function bind(id, fn) { var el = document.getElementById(id); if (el) el.addEventListener('click', fn); }
    bind('btn-connect', connect);
    bind('btn-open-bilibili', function () { chrome.tabs.create({ url: 'https://www.bilibili.com' }); });
    bind('btn-clear-cookie', function () { var inp = document.getElementById('cookie-input'); if (inp) inp.value = ''; var cs = document.getElementById('cookie-status'); if (cs) cs.textContent = ''; chrome.storage.local.remove('biliCookies'); chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: [1001] }).catch(function () {}); });
    bind('btn-start', startExtraction);
    bind('btn-cancel', function () {
      // 设置取消标志，提取脚本会主动停止并返回已获取的数据
      chrome.scripting.executeScript({
        target: { tabId: state.tabId }, world: 'MAIN',
        func: function () { window.__biliCancel = true; },
      }).catch(function () {});
      if (EL.progressStatus) EL.progressStatus.textContent = '正在停止并保存已获取数据...';
    });
    bind('btn-download-html', downloadHTML);
    bind('btn-download-md', downloadMarkdown);
    bind('btn-retry', function () { location.reload(); });
    bind('btn-start-over', function () { state.lastResult = null; init(); });
    bind('btn-view-previous', function () { if (state.lastResult) showDone(state.lastResult.stats); });
    bind('btn-add-theme', async function () {
      var nameEl = document.getElementById('theme-name');
      var keysEl = document.getElementById('theme-keys');
      if (!nameEl || !keysEl) return;
      var name = (nameEl.value || '').trim();
      var ks = (keysEl.value || '').trim();
      if (!name || !ks) return;
      var keys = ks.split(',').map(function (s) { return s.trim(); }).filter(Boolean);
      if (!keys.length) return;
      try {
        var d = await chrome.storage.local.get('customThemes');
        var arr = d.customThemes || [];
        if (arr.length >= 5) { alert('最多 5 个自定义主题'); return; }
        arr.push({ name: name, keys: keys });
        await chrome.storage.local.set({ customThemes: arr });
        nameEl.value = ''; keysEl.value = '';
        // 刷新列表
        var listEl = document.getElementById('theme-list');
        if (listEl) {
          listEl.innerHTML = '';
          arr.forEach(function (t, i) {
            listEl.innerHTML += '<div style="display:flex;justify-content:space-between;align-items:center;padding:4px 6px;margin:2px 0;background:#0d1b2a;border-radius:4px;font-size:12px">' +
              '<span><b>' + (t.name || '') + '</b> <span style="color:#666">(' + (t.keys || []).length + ' 关键词)</span></span>' +
              '<button class="del-theme-btn" data-idx="' + i + '" style="background:0;border:0;color:#f44336;cursor:pointer;font-size:14px;padding:2px 6px">✕</button></div>';
          });
          listEl.querySelectorAll('.del-theme-btn').forEach(function (btn) {
            btn.addEventListener('click', async function () {
              var idx = parseInt(this.getAttribute('data-idx'));
              try {
                var d2 = await chrome.storage.local.get('customThemes');
                var a2 = d2.customThemes || [];
                a2.splice(idx, 1);
                await chrome.storage.local.set({ customThemes: a2 });
                // 重新渲染
                this.closest('div').remove();
              } catch (e) {}
            });
          });
        }
      } catch (e) {}
    });

    init();
  });
})();
