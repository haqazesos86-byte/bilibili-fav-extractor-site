/**
 * content.js — 在 bilibili.com 页面运行
 *
 * 职责：
 * 1. 接收 popup 的提取指令
 * 2. 通过 <script> 注入主世界提取脚本（解决 Cookie 问题）
 * 3. 通过 postMessage 接收进度 → relay 给 popup
 * 4. 提取完成后保存结果到 storage
 */
(function () {
  'use strict';

  var API = {
    NAV: 'https://api.bilibili.com/x/web-interface/nav',
    FOLDER_CREATED: function (mid) { return 'https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=' + mid; },
    FOLDER_COLLECTED: function (mid) { return 'https://api.bilibili.com/x/v3/fav/folder/collected/list?up_mid=' + mid; },
  };

  // ============================================================
  // 主世界脚本注入（<script> 标签，运行在页面上下文）
  // ============================================================
  function injectMainWorldScript(code) {
    var el = document.createElement('script');
    el.textContent = code;
    (document.head || document.documentElement).appendChild(el);
    el.remove(); // 执行后清理
  }

  // 生成主世界提取脚本
  function buildExtractScript(mediaId) {
    // 注意：这段代码将在页面主世界运行，不能引用外部变量
    return `
(function(){
  var mid = '${mediaId}';
  var API = 'https://api.bilibili.com/x/v3/fav/resource/list?media_id=' + mid;

  (async function(){
    var all = [];
    for (var pn = 1; pn <= 700; pn++) {
      try {
        var r = await fetch(API + '&pn=' + pn + '&ps=40&order=mtime&type=0&platform=web&web_location=333.1387', {
          credentials: 'include',
        });
        var d = JSON.parse(await r.text());

        if (d.code !== 0) {
          if (d.code === -412) {
            window.postMessage({__bili:'ext', type:'rateLimit'}, '*');
            await new Promise(function(q){setTimeout(q,300000)});
            continue;
          }
          break;
        }

        var list = (d.data && d.data.medias) || [];
        for (var i = 0; i < list.length; i++) {
          var m = list[i];
          all.push({
            t: (m.title || '').replace(/<[^>]+>/g, ''),
            a: (m.author && m.author.name) || '',
            b: m.bvid || '',
            id: m.id || 0,
            fav_time: m.fav_at || m.ctime || 0,
          });
        }

        // 发进度
        window.postMessage({
          __bili: 'ext',
          type: 'progress',
          page: pn,
          total: all.length,
          pagesTotal: Math.ceil((d.data && d.data.page && d.data.page.count) / 40) || pn,
        }, '*');

        if (!d.data || d.data.has_more === false || d.data.has_more === 0 || !list.length) break;
        await new Promise(function(q){setTimeout(q,500)});
      } catch(e) { break; }
    }

    window.postMessage({__bili:'ext', type:'done', videos:all, total:all.length}, '*');
  })();
})();
`;
  }

  // ============================================================
  // 监听主世界 postMessage
  // ============================================================
  window.addEventListener('message', function (event) {
    var d = event.data;
    if (!d) return;

    // 来自 executeScript 注入脚本的进度
    if (d.__bili === 'p') {
      chrome.runtime.sendMessage({ action: 'extractProgress', page: d.page, total: d.total, pagesTotal: d.pagesTotal });
      return;
    }

    // 来自旧 <script> 注入的进度
    if (d.__bili !== 'ext') return;
    var msg = d;
    chrome.runtime.sendMessage({ action: 'extractWarn', text: 'postMessage: ' + msg.type + (msg.page ? ' p' + msg.page : '') + (msg.total ? ' n=' + msg.total : '') });

    if (msg.type === 'progress') {
      chrome.runtime.sendMessage({
        action: 'extractProgress',
        page: msg.page,
        total: msg.total,
        pagesTotal: msg.pagesTotal,
      });
    } else if (msg.type === 'rateLimit') {
      chrome.runtime.sendMessage({ action: 'extractWarn', text: '限流等待中...' });
    } else if (msg.type === 'done') {
      // 保存结果
      var result = window.BiliFav.classifyAll(msg.videos || []);
      chrome.storage.local.set({
        lastExtraction: {
          mediaId: null,
          videos: msg.videos || [],
          result: result,
          timestamp: Date.now(),
        },
      });
      chrome.runtime.sendMessage({ action: 'extractDone', stats: result.stats });
      chrome.runtime.sendMessage({ action: 'extractComplete' });
    }
  });

  // ============================================================
  // 消息监听
  // ============================================================
  chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    switch (message.action) {
      case 'ping':
        sendResponse({ status: 'ok', url: window.location.href });
        return false;

      case 'startExtraction':
        chrome.runtime.sendMessage({ action: 'extractWarn', text: '收到提取指令' });
        injectMainWorldScript(buildExtractScript(message.mediaId));
        sendResponse({ status: 'ok' });
        return false;

      default:
        return false;
    }
  });
})();
