/**
 * Bilibili Fav Extractor — 分类引擎 & HTML/MD 生成器
 * ==================================================
 * Ported from Python classify_video() + gen_html()
 * 统一分类器：tool → biz → AI-specific → AI 兜底 → 未分类
 */

window.BiliFav = (function () {
  'use strict';

  // ============================================================
  // Helper
  // ============================================================
  function hasAny(s, keywords) {
    return keywords.some(function (k) {
      if (k instanceof RegExp) return k.test(s);
      return s.includes(k);
    });
  }

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ============================================================
  // 智能关键词匹配（自定义主题用）
  // ============================================================
  function smartMatch(title, keyword) {
    var tl = title.toLowerCase().trim();
    var kw = keyword.toLowerCase().trim();
    if (!kw) return false;

    // 1. 直接匹配（当前行为）
    if (tl.indexOf(kw) >= 0) return true;

    // 2. 去标点符号后匹配（"AI编程" ≈ "AI 编程" ≈ "AI、编程"）
    var plain = function (s) { return s.replace(/[^a-z0-9一-鿿]/g, ''); };
    if (plain(tl).indexOf(plain(kw)) >= 0) return true;

    // 3. 英文词边界匹配（"AI" 不误匹配 "TRAIN"）
    if (/^[a-z]/.test(kw) && kw.length >= 2) {
      try {
        var escRe = kw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        if (new RegExp('\\b' + escRe + '\\b', 'i').test(title)) return true;
      } catch (e) {}
    }

    // 4. 多词 AND 匹配：关键词含空格/逗号时，每个词都需要出现
    //    比如关键词 "AI 编程" → 标题必须同时有 "AI" 和 "编程"
    var words = kw.split(/[\s,，、/]+/).filter(Boolean);
    if (words.length > 1) {
      return words.every(function (w) {
        if (w.length < 2) return true;
        return smartMatch(title, w);
      });
    }

    return false;
  }

  // ============================================================
  // SORT_ORDER — 推荐观看排序（数值越小越优先）
  // ============================================================
  var SORT_ORDER = {
    // ── AI ──
    'AI学习路径与入门教程': 1,
    'AI面试/面经/求职': 2,
    'LLM原理与架构': 3,
    'Prompt工程': 4,
    'RAG/知识库': 5,
    'Agent/智能体': 6,
    '预训练与微调': 7,
    '国产大模型': 8,
    '多模态/视觉模型': 9,
    'AI编程/代码生成': 10,
    'AI绘画/设计/视频生成': 11,
    '具身智能/机器人/自动驾驶': 12,
    'AI产品化与产品经理': 13,
    'AI行业趋势': 14,
    'AI+认知/大佬思想': 15,
    'AI安全/对齐/伦理': 16,
    // ── Tool ──
    'Claude Code安装配置与入门': 101,
    'Skill/MCP开发': 102,
    'Cowork/Superpowers': 103,
    'vs其他工具对比': 104,
    'Codex安装配置与入门': 105,
    'Codex项目实战': 106,
    'Skill/Workflow自动化': 107,
    'Open Design等生态工具': 108,
    'Vibe Coding项目实战': 109,
    '0基础设计到实现': 110,
    'UI/设计系统搭配': 111,
    'Cursor使用技巧': 112,
    'Hermes/GitHub Copilot': 113,
    '多工具协作工作流': 114,
    // ── Biz ──
    '第一性原理/逆向思维': 201,
    '人生规划/职业发展': 203,
    '赚钱思维与底层逻辑': 204,
    '商业认知与大佬思想': 205,
    '自律/习惯/执行力': 206,
    '价值投资/复利': 207,
    '被动收入/副业': 208,
    '超级个体理念与规划': 209,
    '独立开发实战案例': 210,
    'SaaS产品化与订阅': 211,
    '从0到1上架App': 212,
    '自媒体起号与涨粉': 213,
    'AI+自媒体结合': 215,
    '流量变现路径': 216,
    '跨境电商入门': 217,
    '外贸SOHO实操': 218,
    '电商运营技巧': 219,
    '信息差套利': 220,
    // ── 未分类 ──
    '未分类': 999,
  };

  // ============================================================
  // 分类函数 — 按优先级：tool → biz → AI-specific → AI兜底 → other
  // ============================================================
  function checkTool(tl) {
    // ---- Claude Code ----
    if (tl.includes('claude code') || tl.includes('claudecode')) {
      if (hasAny(tl, ['skill', 'mcp', '插件'])) return { cat: 'tool', l2: '2.1', l3: '2.1.2', l4: 'Skill/MCP开发' };
      if (hasAny(tl, ['cowork', 'superpowers'])) return { cat: 'tool', l2: '2.1', l3: '2.1.3', l4: 'Cowork/Superpowers' };
      if (hasAny(tl, ['对比', 'vs ', '平替'])) return { cat: 'tool', l2: '2.1', l3: '2.1.4', l4: 'vs其他工具对比' };
      return { cat: 'tool', l2: '2.1', l3: '2.1.1', l4: 'Claude Code安装配置与入门' };
    }
    // ---- Codex ----
    if (tl.includes('codex')) {
      if (hasAny(tl, ['skill', 'workflow'])) return { cat: 'tool', l2: '2.2', l3: '2.2.3', l4: 'Skill/Workflow自动化' };
      if (hasAny(tl, ['open design'])) return { cat: 'tool', l2: '2.2', l3: '2.2.4', l4: 'Open Design等生态工具' };
      if (hasAny(tl, ['新手', '保姆', '安装', '配置', '入门'])) return { cat: 'tool', l2: '2.2', l3: '2.2.1', l4: 'Codex安装配置与入门' };
      return { cat: 'tool', l2: '2.2', l3: '2.2.2', l4: 'Codex项目实战' };
    }
    // ---- Vibe Coding ----
    if (tl.includes('vibe coding') || tl.includes('vibecoding')) {
      if (hasAny(tl, ['ui', '设计', '高级感', '动效'])) return { cat: 'tool', l2: '2.3', l3: '2.3.4', l4: 'UI/设计系统搭配' };
      if (hasAny(tl, ['0基础', '从0', '手搓'])) return { cat: 'tool', l2: '2.3', l3: '2.3.3', l4: '0基础设计到实现' };
      return { cat: 'tool', l2: '2.3', l3: '2.3.2', l4: 'Vibe Coding项目实战' };
    }
    // ---- 其他工具 ----
    if (tl.includes('cursor')) return { cat: 'tool', l2: '2.4', l3: '2.4.1', l4: 'Cursor使用技巧' };
    if (tl.includes('hermes')) return { cat: 'tool', l2: '2.4', l3: '2.4.2', l4: 'Hermes/GitHub Copilot' };
    return null;
  }

  function checkBiz(tl) {
    // ---- 一人公司 ----
    if (hasAny(tl, ['一人公司', '超级个体', 'opc', '个人ip']))
      return { cat: 'biz', l2: '3.1', l3: '3.1.1', l4: '超级个体理念与规划' };
    if (hasAny(tl, ['独立开发', 'indie']))
      return { cat: 'biz', l2: '3.1', l3: '3.1.2', l4: '独立开发实战案例' };
    if (hasAny(tl, ['saas', '订阅', '产品化']))
      return { cat: 'biz', l2: '3.1', l3: '3.1.3', l4: 'SaaS产品化与订阅' };
    if (hasAny(tl, ['上架', 'app store']))
      return { cat: 'biz', l2: '3.1', l3: '3.1.4', l4: '从0到1上架App' };
    // ---- 自媒体 ----
    if (hasAny(tl, ['自媒体', '涨粉', '起号', '短视频', '抖音', '小红书', '博主'])) {
      if (hasAny(tl, ['ai', '人工智能'])) return { cat: 'biz', l2: '3.2', l3: '3.2.3', l4: 'AI+自媒体结合' };
      if (hasAny(tl, ['变现', '赚钱'])) return { cat: 'biz', l2: '3.2', l3: '3.2.4', l4: '流量变现路径' };
      return { cat: 'biz', l2: '3.2', l3: '3.2.1', l4: '自媒体起号与涨粉' };
    }
    // ---- 跨境 ----
    if (hasAny(tl, ['跨境', '亚马逊'])) return { cat: 'biz', l2: '3.3', l3: '3.3.1', l4: '跨境电商入门' };
    if (hasAny(tl, ['外贸', 'soho', '贸易'])) return { cat: 'biz', l2: '3.3', l3: '3.3.2', l4: '外贸SOHO实操' };
    if (hasAny(tl, ['套利', '信息差'])) return { cat: 'biz', l2: '3.3', l3: '3.3.4', l4: '信息差套利' };
    // ---- 投资理财 ----
    if (hasAny(tl, ['巴菲特', '芒格', '复利', '投资', '理财', '股票', '基金']))
      return { cat: 'biz', l2: '3.4', l3: '3.4.1', l4: '价值投资/复利' };
    if (hasAny(tl, ['被动收入', '副业']))
      return { cat: 'biz', l2: '3.4', l3: '3.4.2', l4: '被动收入/副业' };
    if (hasAny(tl, ['纳瓦尔', '贝索斯', '张一鸣', '雷军']))
      return { cat: 'biz', l2: '3.4', l3: '3.4.3', l4: '商业认知与大佬思想' };
    if (hasAny(tl, ['赚钱', '财富', '搞钱', '底层逻辑', '翻身']))
      return { cat: 'biz', l2: '3.4', l3: '3.4.4', l4: '赚钱思维与底层逻辑' };
    // ---- 认知建设 ----
    if (hasAny(tl, ['第一性原理'])) return { cat: 'biz', l2: '3.5', l3: '3.5.1', l4: '第一性原理/逆向思维' };
    if (hasAny(tl, ['自律', '习惯', '执行力', '拖延', '内耗', '专注']))
      return { cat: 'biz', l2: '3.5', l3: '3.5.3', l4: '自律/习惯/执行力' };
    if (hasAny(tl, ['人生', '规划', '职业', '方向', '成长', '认知', '心智']))
      return { cat: 'biz', l2: '3.5', l3: '3.5.4', l4: '人生规划/职业发展' };
    return null;
  }

  function checkAI(tl) {
    // ---- 大模型与基础架构 ----
    if (hasAny(tl, ['transformer', 'attention', '神经网络', '模型架构', '底层原理']))
      return { cat: 'ai', l2: '1.1', l3: '1.1.1', l4: 'LLM原理与架构' };
    if (hasAny(tl, ['微调', 'finetune', 'fine-tun', 'lora', 'sft', 'rlhf']))
      return { cat: 'ai', l2: '1.1', l3: '1.1.2', l4: '预训练与微调' };
    if (hasAny(tl, ['国产', 'deepseek', '千问', 'qwen', '混元', '文心', '通义', '智谱', 'glm', 'kimi', '阶跃']))
      return { cat: 'ai', l2: '1.1', l3: '1.1.3', l4: '国产大模型' };
    if (hasAny(tl, ['多模态', 'multimodal', 'sora', '视频生成', '文生图', 'clip', '扩散', 'diffusion']))
      return { cat: 'ai', l2: '1.1', l3: '1.1.4', l4: '多模态/视觉模型' };
    // ---- AI 应用 ----
    if (hasAny(tl, ['agent', '智能体', 'multi-agent', '多agent', 'ai军团']))
      return { cat: 'ai', l2: '1.2', l3: '1.2.1', l4: 'Agent/智能体' };
    if (hasAny(tl, ['rag', '检索增强', '知识库', '向量', 'embedding', '召回']))
      return { cat: 'ai', l2: '1.2', l3: '1.2.2', l4: 'RAG/知识库' };
    if (hasAny(tl, ['prompt', '提示词']))
      return { cat: 'ai', l2: '1.2', l3: '1.2.3', l4: 'Prompt工程' };
    if (hasAny(tl, ['产品经理', 'ai产品', '产品化', 'pm']))
      return { cat: 'ai', l2: '1.2', l3: '1.2.4', l4: 'AI产品化与产品经理' };
    if (hasAny(tl, ['安全', '对齐', '伦理', '幻觉']))
      return { cat: 'ai', l2: '1.2', l3: '1.2.5', l4: 'AI安全/对齐/伦理' };
    // ---- AI 学习与求职 ----
    if (hasAny(tl, ['学习路径', '从零', '零基础', '入门', '速通', '教程', '新手', '小白']))
      return { cat: 'ai', l2: '1.3', l3: '1.3.1', l4: 'AI学习路径与入门教程' };
    if (hasAny(tl, ['面试', '面经', '求职', 'offer', '校招', '秋招', '简历']))
      return { cat: 'ai', l2: '1.3', l3: '1.3.3', l4: 'AI面试/面经/求职' };
    if (hasAny(tl, ['趋势', '未来', '下半场', '前景', '机遇']))
      return { cat: 'ai', l2: '1.3', l3: '1.3.4', l4: 'AI行业趋势' };
    // ---- AI 细分领域 ----
    if (hasAny(tl, ['ai编程', '代码生成', '用ai写', 'ai开发']))
      return { cat: 'ai', l2: '1.4', l3: '1.4.1', l4: 'AI编程/代码生成' };
    if (hasAny(tl, ['ai绘画', 'ai设计', 'ai作图', 'stable diffusion', 'midjourney', 'ai视频']))
      return { cat: 'ai', l2: '1.4', l3: '1.4.2', l4: 'AI绘画/设计/视频生成' };
    if (hasAny(tl, ['具身', '机器人', 'embodiment', '自动驾驶']))
      return { cat: 'ai', l2: '1.4', l3: '1.4.3', l4: '具身智能/机器人/自动驾驶' };
    if (hasAny(tl, ['马斯克', '黄仁勋', '奥特曼', '姚顺雨', '吴恩达']))
      return { cat: 'ai', l2: '1.4', l3: '1.4.4', l4: 'AI+认知/大佬思想' };
    return null;
  }

  function checkAIFallback(tl) {
    // 宽泛 AI 关键词兜底
    if (hasAny(tl, [/\bai\b/i, '人工智能', '大模型', 'llm', 'gpt', 'chatgpt', 'openai'])) {
      if (hasAny(tl, ['面试', '面经', '求职', 'offer']))
        return { cat: 'ai', l2: '1.3', l3: '1.3.3', l4: 'AI面试/面经/求职' };
      return { cat: 'ai', l2: '1.3', l3: '1.3.1', l4: 'AI学习路径与入门教程' };
    }
    return null;
  }

  /**
   * 统一分类器 — 对单条视频标题进行四级分类
   * @param {string} title  视频标题
   * @param {string} author 视频作者（备用）
   * @returns {{ cat: string, l2: string, l3: string, l4: string }}
   */
  function classifyVideo(title, author) {
    var tl = String(title).toLowerCase();
    return (
      checkTool(tl) ||
      checkBiz(tl) ||
      checkAI(tl) ||
      checkAIFallback(tl) || { cat: 'other', l2: '0', l3: '0.0', l4: '未分类' }
    );
  }

  // ============================================================
  // 批量分类
  // ============================================================
  /**
   * @param {Array} videos  [{ t, a, b, id, fav_time }]
   * @returns {{ ai: {}, tool: {}, biz: {}, other: {}, stats: {} }}
   */
  function classifyAll(videos, customCats) {
    var hasCustom = customCats && customCats.length > 0;

    var catConfig = [
      { key: 'ai', label: '一、AI/人工智能', color: '#1a73e8' },
      { key: 'tool', label: '二、AI编程工具', color: '#e65100' },
      { key: 'biz', label: '三、创业/搞钱', color: '#2e7d32' },
    ];

    var result = hasCustom ? { other: {} } : { ai: {}, tool: {}, biz: {}, other: {} };
    var counts = hasCustom ? { other: 0 } : { ai: 0, tool: 0, biz: 0, other: 0 };

    if (hasCustom) {
      customCats.forEach(function (c, i) {
        var k = 'custom_' + i;
        result[k] = {};
        counts[k] = 0;
      });
      catConfig = customCats.map(function (c, i) {
        return { key: 'custom_' + i, label: c.name, color: '#7b1fa2' };
      });
    }

    videos.forEach(function (v) {
      var tl = String(v.t).toLowerCase();
      var matched = false;

      if (hasCustom) {
        for (var ci = 0; ci < customCats.length; ci++) {
          var c = customCats[ci];
          var ck = 'custom_' + ci;
          if (c.keys && c.keys.length) {
            for (var ki = 0; ki < c.keys.length; ki++) {
              if (smartMatch(tl, c.keys[ki])) {
                if (!result[ck][c.name]) result[ck][c.name] = { l2: c.name, l3: c.name, l4: c.name, videos: [] };
                result[ck][c.name].videos.push(v);
                counts[ck]++;
                matched = true;
                break;
              }
            }
          }
          if (matched) break;
        }
        if (!matched) {
          // 未匹配任何自定义主题 → 未分类
          if (!result.other['未分类']) result.other['未分类'] = { l2: '未分类', l3: '未分类', l4: '未分类', videos: [] };
          result.other['未分类'].videos.push(v);
          counts.other++;
        }
      } else {
        var r = classifyVideo(v.t, v.a);
        var key = r.l3 + '|' + r.l4;
        if (!result[r.cat][key]) {
          result[r.cat][key] = { l2: r.l2, l3: r.l3, l4: r.l4, videos: [] };
        }
        result[r.cat][key].videos.push(v);
        counts[r.cat]++;
      }
    });

    var total = 0;
    for (var ck in counts) total += counts[ck];
    var stats = { ai: 0, tool: 0, biz: 0, other: 0, total: total, custom: {} };
    if (hasCustom) {
      stats.other = counts.other || 0;
      customCats.forEach(function (c, i) {
        var k = 'custom_' + i;
        stats.custom[c.name] = counts[k] || 0;
      });
    } else {
      stats.ai = counts.ai;
      stats.tool = counts.tool;
      stats.biz = counts.biz;
      stats.other = counts.other;
    }
    return {
      classified: result,
      stats: stats,
    };
  }

  // ============================================================
  // 排序
  // ============================================================
  function sortKeys(classifiedData) {
    var keys = Object.keys(classifiedData);
    keys.sort(function (a, b) {
      var va = SORT_ORDER[classifiedData[a].l4] || 999;
      var vb = SORT_ORDER[classifiedData[b].l4] || 999;
      return va - vb;
    });
    return keys;
  }

  // ============================================================
  // 按月分组（当分类下 > 50 条时使用）
  // ============================================================
  function groupByMonth(videos) {
    var groups = {};
    videos.forEach(function (v) {
      var d = new Date((v.fav_time || 0) * 1000);
      var key = d.getFullYear() + '年' + (d.getMonth() + 1) + '月';
      if (!groups[key]) groups[key] = [];
      groups[key].push(v);
    });
    var months = Object.keys(groups);
    months.sort().reverse();
    return months.map(function (m) { return { month: m, videos: groups[m] }; });
  }

  // ============================================================
  // HTML 生成器
  // ============================================================
  function genHTML(result) {
    var classified = result.classified;
    var stats = result.stats;
    var now = new Date().toLocaleString('zh-CN');

    function makeID(l3, l4) {
      return l3.replace(/\./g, '') + l4.slice(0, 6).replace(/[/\s]/g, '');
    }

    // 判断是否有自定义分类
    var catConfig;
    if (result.stats && result.stats.custom && Object.keys(result.stats.custom).length > 0) {
      var idx = 0;
      catConfig = [];
      for (var cn in result.stats.custom) {
        catConfig.push({ key: 'custom_' + idx, label: cn, color: '#7b1fa2' });
        idx++;
      }
    } else {
      catConfig = [
        { key: 'ai', label: '一、AI/人工智能', color: '#1a73e8' },
        { key: 'tool', label: '二、AI编程工具', color: '#e65100' },
        { key: 'biz', label: '三、创业/搞钱', color: '#2e7d32' },
      ];
    }

    var h = [];
    h.push('<!DOCTYPE html>');
    h.push('<html lang="zh-CN">');
    h.push('<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">');
    h.push('<title>B站收藏夹 - AI方向学习笔记</title>');
    h.push('<style>');
    h.push('*{margin:0;padding:0;box-sizing:border-box}');
    h.push('body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;background:#f5f6fa;color:#2c3e50;line-height:1.7}');
    h.push('.header{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 50%,#0f3460 100%);color:#fff;padding:40px 20px;text-align:center}');
    h.push('.header h1{font-size:28px;margin-bottom:8px}');
    h.push('.header p{font-size:14px;opacity:.8}');
    h.push('.container{max-width:1000px;margin:0 auto;padding:20px}');
    h.push('.stats{display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px}');
    h.push('.stat-card{flex:1;min-width:130px;background:#fff;border-radius:12px;padding:20px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06)}');
    h.push('.stat-card .num{font-size:30px;font-weight:700;color:#1a73e8}');
    h.push('.stat-card .label{font-size:13px;color:#888;margin-top:4px}');
    h.push('.branch{background:#fff;border-radius:12px;padding:24px;margin-bottom:24px;box-shadow:0 2px 8px rgba(0,0,0,.06);overflow-x:auto}');
    h.push('.branch pre{font-family:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;font-size:12px;line-height:1.5;color:#333}');
    h.push('.toc{background:#fff;border-radius:12px;padding:24px;margin-bottom:24px;box-shadow:0 2px 8px rgba(0,0,0,.06)}');
    h.push('.toc h2{font-size:18px;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid #e8e8e8}');
    h.push('.tree{list-style:none;padding:0;margin:0}');
    h.push('.tree .cat{font-weight:600;font-size:15px;padding:10px 16px;margin:6px 0;background:#f0f2f5;border-radius:8px;cursor:pointer;display:flex;justify-content:space-between;align-items:center}');
    h.push('.tree .cat:hover{background:#e3e8ef}');
    h.push('.tree .cat .badge{font-size:12px;color:#666;background:#e0e0e0;padding:2px 12px;border-radius:10px}');
    h.push('.tree .sub{display:none;padding-left:24px;margin:4px 0}');
    h.push('.tree .sub.open{display:block}');
    h.push('.tree .sub li{list-style:none;margin:2px 0}');
    h.push('.tree .sub a{display:block;padding:5px 12px;font-size:13px;color:#444;text-decoration:none;border-radius:6px}');
    h.push('.tree .sub a:hover{background:#e8f0fe;color:#1a73e8}');
    h.push('.search-box{margin-bottom:16px}');
    h.push('.search-box input{width:100%;padding:10px 16px;border:2px solid #e0e0e0;border-radius:8px;font-size:14px;outline:none;transition:border-color .2s}');
    h.push('.search-box input:focus{border-color:#1a73e8}');
    h.push('.section{background:#fff;border-radius:12px;padding:20px 24px;margin-bottom:12px;box-shadow:0 2px 8px rgba(0,0,0,.06)}');
    h.push('.section h3{font-size:16px;margin-bottom:8px;display:flex;align-items:center;gap:8px}');
    h.push('.section h3 .tag{font-size:11px;color:#fff;background:#1a73e8;padding:2px 10px;border-radius:10px;font-weight:400}');
    h.push('.section .info{font-size:12px;color:#999;margin-bottom:10px}');
    h.push('.vl{counter-reset:n}');
    h.push('.vl .vi{display:flex;align-items:baseline;padding:4px 0;border-bottom:1px solid #f0f0f0;font-size:13px}');
    h.push('.vl .vi::before{counter-increment:n;content:counter(n);min-width:26px;font-size:11px;color:#aaa;text-align:right;padding-right:8px;flex-shrink:0}');
    h.push('.vl .vi a{color:#333;text-decoration:none;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}');
    h.push('.vl .vi a:hover{color:#1a73e8}');
    h.push('.vl .vi .au{font-size:11px;color:#999;margin-left:6px;white-space:nowrap;flex-shrink:0}');
    h.push('.nav-row{display:flex;justify-content:space-between;padding-top:10px;margin-top:10px;border-top:1px solid #eee;font-size:12px}');
    h.push('.nav-row a{color:#1a73e8;text-decoration:none}');
    h.push('.section-title{font-size:20px;font-weight:700;margin-bottom:16px;padding:12px 0 4px}');
    h.push('@media(max-width:768px){.header h1{font-size:22px}.container{padding:12px}.section{padding:16px}}');
    h.push('</style></head><body>');

    // Header
    h.push('<div class="header">');
    h.push('<h1>B站收藏夹 - AI方向学习笔记</h1>');
    h.push('<p>总计 ' + stats.total + ' 条收藏视频 · ' + now + '</p>');
    h.push('<p style="font-size:12px;opacity:.6;margin-top:4px">AI/人工智能 ' + stats.ai + '条 · AI编程工具 ' + stats.tool + '条 · 创业/搞钱 ' + stats.biz + '条' + (stats.other ? ' · 其他 ' + stats.other + '条' : '') + '</p>');
    h.push('</div>');

    h.push('<div class="container">');

    // Stats cards
    h.push('<div class="stats">');
    catConfig.forEach(function (c) {
      var count = stats[c.key];
      h.push('<div class="stat-card"><div class="num">' + count + '</div><div class="label">' + c.label + '</div></div>');
    });
    h.push('<div class="stat-card"><div class="num">' + stats.total + '</div><div class="label">总计</div></div>');
    h.push('</div>');

    // Search box
    h.push('<div class="search-box"><input type="text" id="searchInput" placeholder="搜索视频标题..." oninput="filterVideos(this.value)"></div>');

    // TOC
    h.push('<div class="toc" id="top"><h2>📑 目录 - 快速跳转</h2>');
    h.push('<ul class="tree">');
    catConfig.forEach(function (c) {
      var data = classified[c.key];
      var keys = sortKeys(data);
      var catTotal = keys.reduce(function (sum, k) { return sum + data[k].videos.length; }, 0);
      if (catTotal === 0) return;
      h.push('<li class="cat" onclick="this.nextElementSibling.classList.toggle(\'open\')"><span>' + c.label + '</span><span class="badge">' + catTotal + '个</span></li>');
      h.push('<ul class="sub">');
      keys.forEach(function (k) {
        var item = data[k];
        h.push('<li><a href="#' + makeID(item.l3, item.l4) + '">' + item.l3 + ' ' + item.l4 + ' <span style="color:#999">(' + item.videos.length + ')</span></a></li>');
      });
      h.push('</ul>');
    });
    h.push('</ul></div>');

    // Sections
    catConfig.forEach(function (c) {
      var data = classified[c.key];
      var keys = sortKeys(data);
      var catTotal = keys.reduce(function (sum, k) { return sum + data[k].videos.length; }, 0);
      if (catTotal === 0) return;
      h.push('<div class="section-title" id="sec-' + c.key + '">' + c.label + ' <span style="font-weight:400;font-size:14px;color:#666">共' + catTotal + '条</span></div>');
      keys.forEach(function (k, idx) {
        var item = data[k];
        h.push('<div class="section" id="' + makeID(item.l3, item.l4) + '">');
        h.push('<h3>' + item.l3 + ' → ' + item.l4 + ' <span class="tag">' + item.videos.length + '个</span></h3>');
        h.push('<div class="info">推荐观看顺序 - 从基础到进阶</div>');
        // 多于 50 条则按月分组
        if (item.videos.length > 50) {
          var mg = groupByMonth(item.videos);
          mg.forEach(function (g) {
            h.push('<h4 style="margin:10px 0 4px;font-size:14px;color:#555">' + g.month + ' <span style="font-size:10px;color:#999">' + g.videos.length + '个</span></h4>');
            h.push('<div class="vl">');
            g.videos.forEach(function (v) {
              h.push('<div class="vi"><a href="' + (v.b ? 'https://www.bilibili.com/video/' + v.b : '#') + '" target="_blank">' + esc(v.t) + '</a><span class="au">' + esc(v.a || '') + '</span></div>');
            });
            h.push('</div>');
          });
        } else {
          h.push('<div class="vl">');
          item.videos.forEach(function (v) {
            h.push('<div class="vi"><a href="' + (v.b ? 'https://www.bilibili.com/video/' + v.b : '#') + '" target="_blank" title="' + esc(v.t) + '">' + esc(v.t) + '</a><span class="au">' + esc(v.a || '') + '</span></div>');
          });
          h.push('</div>');
        }
        h.push('<div class="nav-row">');
        h.push('<a href="#top">↑ 返回目录</a>');
        if (idx < keys.length - 1) {
          var nk = data[keys[idx + 1]];
          h.push('<a href="#' + makeID(nk.l3, nk.l4) + '">下一节 ' + nk.l3 + ' ' + nk.l4 + ' ↓</a>');
        } else {
          h.push('<span></span>');
        }
        h.push('</div></div>');
      });
    });

    // Search script
    h.push('<script>');
    h.push('function filterVideos(q){q=q.toLowerCase().trim();var sections=document.querySelectorAll(".section");sections.forEach(function(s){if(!q){s.style.display="";return}var items=s.querySelectorAll(".vi");var visible=0;items.forEach(function(vi){var txt=vi.textContent.toLowerCase();if(txt.includes(q)){vi.style.display="";visible++}else{vi.style.display="none"}});if(visible>0||s.querySelector("h3").textContent.toLowerCase().includes(q)){s.style.display=""}else{s.style.display="none"}})}');
    h.push('</script>');

    h.push('</div></body></html>');
    return h.join('\n');
  }

  // ============================================================
  // Markdown 生成器
  // ============================================================
  function genMarkdown(result) {
    var classified = result.classified;
    var stats = result.stats;
    var now = new Date().toLocaleString('zh-CN');
    var lines = [];

    lines.push('# B站收藏夹 - AI方向学习笔记');
    lines.push('');
    lines.push('> 生成时间：' + now);
    lines.push('> 总计 ' + stats.total + ' 条收藏视频');
    lines.push('');

    // 检测是否有自定义分类
    var catConfig;
    if (stats.custom && Object.keys(stats.custom).length > 0) {
      var idx = 0;
      catConfig = [];
      for (var cn in stats.custom) {
        catConfig.push({ key: 'custom_' + idx, label: cn });
        idx++;
      }
    } else {
      catConfig = [
        { key: 'ai', label: '一、AI/人工智能' },
        { key: 'tool', label: '二、AI编程工具' },
        { key: 'biz', label: '三、创业/搞钱' },
      ];
      lines.push('> AI/人工智能 ' + stats.ai + '条 · AI编程工具 ' + stats.tool + '条 · 创业/搞钱 ' + stats.biz + '条');
    }
    lines.push('');

    catConfig.forEach(function (c) {
      var data = classified[c.key];
      if (!data) return;
      var keys = sortKeys(data);
      if (keys.length === 0) return;

      lines.push('## ' + c.label);
      lines.push('');

      keys.forEach(function (k) {
        var item = data[k];
        lines.push('### ' + item.l3 + ' → ' + item.l4 + '（' + item.videos.length + '个）');
        lines.push('');

        // 多于 50 条则按月分组
        if (item.videos.length > 50) {
          var mg = groupByMonth(item.videos);
          mg.forEach(function (g) {
            lines.push('#### ' + g.month + '（' + g.videos.length + '个）');
            lines.push('');
            g.videos.forEach(function (v, i) {
              var href = v.b ? 'https://www.bilibili.com/video/' + v.b : '#';
              lines.push((i + 1) + '. [' + v.t + '](' + href + ') - ' + (v.a || ''));
            });
            lines.push('');
          });
        } else {
          item.videos.forEach(function (v, i) {
            var href = v.b ? 'https://www.bilibili.com/video/' + v.b : '#';
            lines.push((i + 1) + '. [' + v.t + '](' + href + ') - ' + (v.a || ''));
          });
          lines.push('');
        }
      });
    });

    return lines.join('\n');
  }

  // ============================================================
  // Public API
  // ============================================================
  return {
    SORT_ORDER: SORT_ORDER,
    classifyVideo: classifyVideo,
    classifyAll: classifyAll,
    sortKeys: sortKeys,
    genHTML: genHTML,
    genMarkdown: genMarkdown,
  };
})();
