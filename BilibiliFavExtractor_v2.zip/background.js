/**
 * background.js — Service Worker
 * 代理 API 请求（content script → background → fetch）
 * 粘贴 Cookie 的 DNR 规则由 popup 直接创建，不走 background 中转
 */

chrome.runtime.onInstalled.addListener(function (details) {
  if (details.reason === 'install') {
    chrome.tabs.create({ url: 'https://www.bilibili.com/' });
  }
});

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.action === 'bgFetch' || message.action === 'bgFetchJSON') {
    fetch(message.url, { credentials: 'include' })
      .then(function (r) { return r.text(); })
      .then(function (text) {
        if (message.action === 'bgFetch') {
          sendResponse({ ok: true, data: text });
        } else {
          try {
            var json = JSON.parse(text);
            sendResponse({ ok: true, data: json });
          } catch (e) {
            sendResponse({ ok: false, error: 'JSON parse error: ' + e.message + ' | body: ' + text.slice(0, 200) });
          }
        }
      })
      .catch(function (err) {
        sendResponse({ ok: false, error: err.message });
      });
    return true;
  }
});
