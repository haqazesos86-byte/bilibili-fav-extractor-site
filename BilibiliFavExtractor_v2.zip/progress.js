/**
 * progress.js — 提取进度窗口逻辑
 */
(function () {
  'use strict';

  var EL = {
    fill: document.getElementById('fill'),
    page: document.getElementById('page'),
    count: document.getElementById('count'),
    status: document.getElementById('status'),
    done: document.getElementById('done'),
    total: document.getElementById('total'),
    diag: document.getElementById('diag'),
    jscheck: document.getElementById('jscheck'),
  };

  if (EL.jscheck) EL.jscheck.textContent = '✅ JS 已加载';

  var logLines = [];
  function log(msg) {
    logLines.push('[' + new Date().toLocaleTimeString() + '] ' + msg);
    if (EL.diag) { EL.diag.textContent = logLines.join('\n'); EL.diag.scrollTop = EL.diag.scrollHeight; }
  }
  log('进度窗口启动');

  chrome.runtime.onMessage.addListener(function (msg) {
    log('收到消息: ' + msg.action);

    if (msg.action === 'extractProgress') {
      var pct = msg.pagesTotal > 0 ? Math.round(msg.page / msg.pagesTotal * 100) : 0;
      if (EL.fill) EL.fill.style.width = pct + '%';
      if (EL.page) EL.page.textContent = '第 ' + msg.page + ' 页';
      if (EL.count) EL.count.textContent = '已获取 ' + (msg.total || 0) + ' 条';
      log('进度: page=' + msg.page + '/' + (msg.pagesTotal || '?') + ' total=' + msg.total);
    } else if (msg.action === 'extractDone') {
      chrome.storage.local.get('lastExtraction', function (d) {
        if (d.lastExtraction && d.lastExtraction.result) {
          if (EL.done) EL.done.style.display = 'block';
          if (EL.total) EL.total.textContent = d.lastExtraction.result.stats.total || 0;
          if (EL.status) {
            EL.status.textContent = '✅ 提取完成！共 ' + d.lastExtraction.result.stats.total + ' 条';
            EL.status.className = 'status-box';
          }
          log('完成: ' + d.lastExtraction.result.stats.total + ' 条');
        }
      });
    } else if (msg.action === 'extractWarn') {
      if (EL.status) {
        EL.status.textContent = '⚠️ ' + msg.text;
        EL.status.className = 'status-box warn';
      }
      log('警告: ' + msg.text);
    }
  });

  // 主动查询是否有正在进行的提取
  log('查询已有提取结果...');
  chrome.storage.local.get('lastExtraction', function (d) {
    if (d.lastExtraction && d.lastExtraction.result) {
      log('已有结果: ' + d.lastExtraction.result.stats.total + ' 条');
    } else {
      log('无已有结果');
    }
  });
})();
